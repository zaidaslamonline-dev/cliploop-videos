Sanatan Reel Autopilot - media bundle

Place the contents of this ZIP at the repository root.

Mapped files:
- assets/bgm/bgm_main.mp3        <- sub_clair-indian-hindi-632690.mp3 (user-confirmed main Indian flute)
- assets/sfx/whoosh.mp3          <- lordsonny-whoosh-cinematic-161021.mp3
- assets/sfx/bass_hit.mp3        <- lordsonny-rock-cinematic-161648.mp3
- assets/bgm/alternate_track.mp3 <- land_of_books_youtube-secret-shadows-sail-246484.mp3 (extra alternate track; not selected as main BGM)

No particles overlay was uploaded. That asset is optional.
